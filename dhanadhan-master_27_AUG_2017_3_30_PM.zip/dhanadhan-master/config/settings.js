module.exports = {
    flipkart:{
        url: 'affiliate-api.flipkart.net',
        trackingId: 'jogender8',
        token: '24c5fb597dab4540808a7e15bbe71007'
    }
}